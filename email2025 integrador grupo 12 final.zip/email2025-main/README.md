GestorEmailsUCP/
├── pom.xml
├── src/
│   ├── main/java/com/ucp/gestor/
│   │   ├── Contacto.java
│   │   ├── Email.java
│   │   ├── BandejaType.java
│   │   ├── Bandeja.java
│   │   ├── Filtro.java
│   │   ├── GestorEmails.java
│   │   └── MainDemo.java
│   └── test/java/com/ucp/gestor/
│       └── GestorEmailsTest.java
└── .github/workflows/
    └── maven-ci.yml
