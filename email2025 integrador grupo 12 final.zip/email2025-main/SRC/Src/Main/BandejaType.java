package SRC.Src.Main;

public enum BandejaType {
    ENTRADA,
    ENVIADOS,
    BORRADORES,
    ELIMINADOS,
    FAVORITOS
}